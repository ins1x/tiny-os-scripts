::--------------------------------------------------------------
:: Utility: Script to display hardware IDs of specific devices
:: Author: Bashrat,Coop75 & JakeLD
:: Last modification: v1.5 04/01/2009
:: Compatibility: Windows 2K-XP
::--------------------------------------------------------------
:: RAID HWID Tool wrapper from: OverFlow
::--------------------------------------------------------------
:: HDA Audio wrapper from: Debugger (DriverPacks Team)